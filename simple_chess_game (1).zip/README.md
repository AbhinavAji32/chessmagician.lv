# Simple Chess Game

This is a simple command-line chess game built with Python using the `python-chess` library.

## How to Run

1. Install dependencies:

```
pip install -r requirements.txt
```

2. Run the game:

```
python chess_game.py
```

## Usage

- Enter moves in UCI format (e.g., `e2e4`)
- Type `exit` to quit the game.
