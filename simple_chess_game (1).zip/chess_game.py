import chess
import os

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_board(board):
    print(board)

def main():
    board = chess.Board()
    print("Welcome to Command-Line Chess!")
    print("Enter moves in UCI format (e.g., e2e4). Type 'exit' to quit.")
    print_board(board)

    while not board.is_game_over():
        move_input = input(f"{'White' if board.turn else 'Black'} to move: ").strip()
        if move_input.lower() == 'exit':
            print("Game exited.")
            break

        try:
            move = chess.Move.from_uci(move_input)
            if move in board.legal_moves:
                board.push(move)
                clear_screen()
                print_board(board)
            else:
                print("Illegal move. Try again.")
        except:
            print("Invalid input. Please enter move in UCI format (e.g., e2e4).")

    if board.is_checkmate():
        print("Checkmate!")
    elif board.is_stalemate():
        print("Stalemate.")
    elif board.is_insufficient_material():
        print("Draw due to insufficient material.")
    elif board.is_seventyfive_moves():
        print("Draw due to 75-move rule.")
    elif board.is_fivefold_repetition():
        print("Draw due to fivefold repetition.")
    else:
        print("Game over.")

if __name__ == "__main__":
    main()
